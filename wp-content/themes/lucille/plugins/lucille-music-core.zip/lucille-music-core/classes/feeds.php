<?php 

/*
SWP class that handles the feeds
*/

class Feeds
{	
	private $siteName;
	private $feedRssName;
	private $feediCalName;
	private $site_rss_url;
	private $site_ical_url;
	private $site_ical_call;

	public function __construct() {
		$this->siteName = str_replace(" ", "_", get_bloginfo('name'));	
		
		$this->feedRssName  = sanitize_title(get_bloginfo('name')).'-rss';
		$this->feediCalName = sanitize_title(get_bloginfo('name')).'-ical';			

		$this->site_rss_url   = get_bloginfo('url') . '/?feed='.$this->feedRssName;
		$this->site_ical_url  = get_bloginfo('url') . '/?feed='.$this->feediCalName;
		$this->site_ical_call = str_replace('http://', 'webcal://', $this->site_ical_url);
    }

    function get_rss_feeds()
    {
    	return $this->site_rss_url;
    }

    function get_ical_feeds()
    {
    	return $this->site_ical_call;
    }

    function start_feeds() {  
  		add_action('init', array( $this, 'initialize_feeds') );
	}


	function initialize_feeds() {  
  		add_feed($this->feedRssName, array( $this, 'feed_rss') );
  		add_feed($this->feediCalName, array( $this, 'feed_icalendar') );
	}

	function feed_icalendar()
	{
		$events = $this->load_events();

		 if( count($events) == 0 ) {
		 	return;
		 }

		$count = 1;
	    $total = count($events);

	    $title=get_bloginfo('name');
      	$filename = $this->feediCalName . '-icalendar';      	

	    foreach($events as $one_event) 
	    {
	    	if($count == 1) {
        		header('Content-type: text/calendar');
        		header('Content-Disposition: attachment; filename="calendar.ics"');  

        		echo("BEGIN:VCALENDAR\r\n" . 
        			"VERSION:2.0\r\n");
        		
        		if($total > 1) {
          			echo("X-WR-CALNAME: $title\r\n");
        		}
        		echo("PRODID:SWP 1.0 WORDPRESS THEME\r\n".
        			"CALSCALE:GREGORIAN\r\n".
        			"X-WR-TIMEZONE:Etc/GMT\r\n".
        			"METHOD:PUBLISH\r\n".
        			"BEGIN:VTIMEZONE\r\n".
        			"TZID:GMT\r\n".
        			"BEGIN:STANDARD\r\n".
        			"DTSTART:20071028T010000\r\n".
        			"TZOFFSETTO:+0000\r\n".
        			"TZOFFSETFROM:+0000\r\n".
        			"END:STANDARD\r\n".
        			"END:VTIMEZONE\r\n");
      		}


      		$event_venue = " @ " . $one_event['venue'];
      		if( trim($one_event['venue']) == "")	{
      			$event_venue = "";
      		}
      		$event_location=$one_event['calendar_details_ical'] . esc_html__('in','lucille-music-core') . $one_event['city'] .  $event_venue;
			if( $one_event['calendar_details_ical'] === $one_event['venue'])
			{
				$event_location=$one_event['city'] .  $event_venue;
			}

        	echo("BEGIN:VEVENT\r\n" . 
        		"SUMMARY:" . esc_html($one_event['calendar_summary_ical']) . "\r\n" .
        		"DESCRIPTION:" . esc_html($event_location)  . "\r\n" . 
        		"LOCATION:" . esc_html($event_location) . "\r\n" . "UID:" . esc_html($one_event['calendar_start']) . '-' . esc_html($one_event['id']) . '-' . esc_html($this->siteName) . "\r\n" .
        		"URL:" . esc_html($one_event['permalink']) . "\r\n");
        	
        	if(strlen($one_event['calendar_start']) == 8) {
          		echo("DTSTART;VALUE=DATE;TZID=GMT:" . esc_html($one_event['calendar_start']) . 
          		"\r\nDTEND;VALUE=DATE;TZID=GMT:" . esc_html($one_event['calendar_end']) . "\r\n");
        	}
        	else {
          		echo("DTSTART;VALUE=DATE-TIME;TZID=GMT:" . esc_html($one_event['calendar_start']) . "\r\n" . 
          		"DTEND;VALUE=DATE-TIME;TZID=GMT:" . esc_html($one_event['calendar_end']) . "\r\n");
        	}

        	echo("DTSTAMP:" . date('Ymd') . "T" . date('his') . "Z\r\n" . 
        		"END:VEVENT\r\n");
        	if($count == $total) {
          		echo("END:VCALENDAR");
        	}

      		$count++;
	    }
	}

	function feed_rss()
	{
		header('Content-type: text/xml; charset='.get_bloginfo('charset'));
		echo('<?xml version="1.0" encoding="'.get_bloginfo('charset').'"?>
			<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">');
	
		$events = $this->load_events();
		$title=get_bloginfo('name');

		if( count($events) == 0 ) {
			echo('</rss>');
			return;
		}

		$count = 1;
		$total = count($events);
		
		foreach($events as $one_event) 
	    {
	    	if($count == 1) : ?>
			
			<channel>				
			<title><?php echo esc_html($title); ?></title>
			<description><?php echo esc_html($title); ?></description>
			<atom:link href="<?php echo esc_html($this->site_rss_url); ?>" rel="self" type="application/rss+xml" />
			<link><?php echo get_bloginfo('url'); ?></link>
			
			<?php endif; ?>			
			<item>
				<title><?php echo get_bloginfo('name')  . ' ' . esc_html__('at','lucille-music-core') . ' ' . esc_html($one_event['venue']) . ' ' .esc_html__('in','lucille-music-core') . ' ' . esc_html($one_event['city']) . ' ' . esc_html__('on','lucille-music-core') . ' ' . esc_html($one_event['calendar_start_nice']); ?></title>
				<description><?php echo('<![CDATA['); ?>
			<ul>
				
				<li><strong><?php echo esc_html__('Date','lucille-music-core'); ?>:</strong>
				<?php echo esc_html($one_event['calendar_start_nice']); ?>
				<?php ?>
				</li>
			<?php if($one_event['calendar_start_time']) { ?>
				<li><strong><?php echo esc_html__('Time','lucille-music-core'); ?>:</strong> 
				<?php echo esc_html($one_event['calendar_start_time_nice']); ?></li>
			<?php } ?>
				<li><strong><?php echo esc_html__('City','lucille-music-core'); ?>:</strong> 
				<?php echo esc_html($one_event['city']); ?></li>
				<li><strong><?php echo esc_html__('Venue','lucille-music-core'); ?>:</strong> 
				<?php echo esc_html($one_event['venue']); ?></li>
			
			<?php if($one_event['event_buy_tickets_url']) { ?>
				<li><strong><?php echo esc_html__('Buy tickets','lucille-music-core'); ?>:</strong> 
				<?php echo esc_html($one_event['event_buy_tickets_url']); ?></li>
			<?php } ?>
			
				<li>
					<a href="http://www.google.com/calendar/event?action=TEMPLATE&amp;text=<?php echo urlencode($one_event['calendar_summary_ical']); ?>&amp;text=<?php echo urlencode($one_event['calendar_summary_ical']) ?>&amp;dates=<?php echo $one_event['calendar_start'] ?>/<?php echo $one_event['calendar_end'] ?>&amp;sprop=website:<?php echo urlencode(get_bloginfo('url')); ?>
						&amp;sprop=name:<?php echo urlencode(get_bloginfo('name')); ?>
						&amp;location=<?php echo urlencode($one_event['venue']); ?>&amp;details=<?php echo urlencode($one_event['calendar_details_ical']); ?>&amp;trp=true;"><?php echo esc_html__('Add to Google calendar','lucille-music-core'); ?></a> 
						| 
					<a href="<?php echo esc_url($this->site_ical_url); ?>"><?php echo esc_html__('Download iCalendar','lucille-music-core'); ?></a>;
					
				</li>			
			</ul>
			]]></description>
				<link><?php echo esc_html($one_event['permalink']); ?></link>
				<guid isPermaLink="false">#show-<?php echo esc_html($one_event['id']); ?></guid>
			</item>
		<?php
			if($count == $total) echo('</channel>');
			$count++;
		}
		echo('</rss>');
	}

	private function load_events()
	{
		$args = array(
			'numberposts'	=> 100,
			'posts_per_page'   => 100,
			'offset'           => 0,
			'category'         => '',
			'orderby'          => array('event_date' => 'ASC', 'event_time' => 'ASC'),
			'order'            => 'ASC',
			'include'          => '',
			'exclude'          => '',
			'meta_key'         => 'event_date',
			'meta_value'       => '',
			'post_type'        => 'js_events',
			'post_mime_type'   => '',
			'post_parent'      => '',
			'post_status'      => 'publish',
			'meta_query' => array(
				'relation' => 'AND',
				'event_date' => array(
				   'key' => 'event_date',
				   'value' => date('Y/m/d',current_time('timestamp')),
				   'compare' => '>='
				),
				'event_time' => array(
				   'key' => 'event_time'
				)				
			),
			'suppress_filters' => false
		);

		$wp_query= null;
		$wp_query = new WP_Query();
		$wp_query->query($args);

		$events=array();
		while ($wp_query->have_posts()) {
			$wp_query->the_post();

			$one_event['calendar_details_ical'] = get_the_title();
			$one_event['calendar_summary_ical'] = get_bloginfo('name');

			$one_event['id'] = get_the_ID();
			$one_event['permalink'] = get_the_permalink();

			$event_date=str_replace("/","", get_post_meta(get_the_ID(), 'event_date', true));
			$event_time=str_replace(":","", get_post_meta(get_the_ID(), 'event_time', true));

			$one_event['calendar_start']=$this->convertToGmt($event_date." ".$event_time."00");
			$one_event['calendar_start_time']=$event_time;
			$one_event['calendar_end']=$this->convertToGmt($event_date." ".$event_time."00", true);

			$one_event['city'] = esc_html(get_post_meta(get_the_ID(), 'event_location', true));
			$one_event['venue'] = esc_html(get_post_meta(get_the_ID(), 'event_venue', true));
			$one_event['event_buy_tickets_url'] = esc_html(get_post_meta(get_the_ID(), 'event_buy_tickets_url', true));
			
			$one_event['calendar_start_nice'] = $this->convertToDateNice($event_date);
			$one_event['calendar_start_time_nice']= $this->convertToTimeNice($event_date." ".$event_time."00");

			array_push($events, $one_event);				
		}
		/* Reset main query loop */
		wp_reset_query ();
		wp_reset_postdata ();	
		
		return $events;
	}

	/* convert time to GMT taking into consideration current timezone. $add_hours used for end time */
	private function convertToGmt($string, $add_hours = false)
	{
		$format = 'Ymd His';
		try{
			$timezone = get_option('timezone_string', date_default_timezone_get());
			
			$datetime = date_create( $string, new DateTimeZone( $timezone ) );
		}
		catch(Exception $e)
		{
			return gmdate( $format, 0 );
		}
		
		if ( ! $datetime )
			return gmdate( $format, 0 );

		if( $add_hours ) {
			date_add($datetime, date_interval_create_from_date_string('2 hours'));
		}
		
		$datetime->setTimezone( new DateTimeZone( 'UTC' ) );
		return str_replace(' ', 'T', $datetime->format( $format ) );
	}

	/* show date in format July 12, 2018 */
	private function convertToDateNice($event_date)
	{
		if ($event_date != "") {
			@$event_date = str_replace("/","-", $event_date);
			@$dateObject = new DateTime($event_date);
		}

		return phpversion() >= "5.3" ? date_i18n(get_option('date_format'), $dateObject->getTimestamp()) : date_i18n(get_option('date_format'), $dateObject->format('U'));	
	}

	/* show time in format 9:30 PM */
	private function convertToTimeNice($event_date_time)
	{
		$datetime = date_create( $event_date_time );
		return $datetime->format( 'g:i A' );	
	}

}

?>